import SwiftUI

struct ResultsView: View {
    @EnvironmentObject private var app: AppStore
    @Environment(\.dismiss) private var dismiss

    let mode: PracticeMode
    let correctCount: Int
    let total: Int
    let xpGained: Int
    let wrongItems: [ReviewItem]
    let onCommit: () -> Void

    private var accuracy: Int {
        guard total > 0 else { return 0 }
        let value = (Double(correctCount) / Double(total)) * 100.0
        return Int(value.rounded())
    }

    var body: some View {
        NavigationStack {
            ZStack {
                StrongBackground()

                ScrollView(showsIndicators: false) {
                    VStack(spacing: 14) {
                        GlassCard {
                            VStack(alignment: .leading, spacing: 10) {
                                Text("Resultado")
                                    .font(.system(size: 20, weight: .bold))

                                HStack(spacing: 10) {
                                    Metric(title: "Precisão", value: "\(accuracy)%", tint: AppColors.brandBlue)
                                    Metric(title: "XP", value: "+\(xpGained)", tint: AppColors.brandGreen)
                                    Metric(title: "Acertos", value: "\(correctCount)/\(total)", tint: AppColors.brandPurple)
                                }
                            }
                        }
                        .padding(.horizontal, 16)

                        if !wrongItems.isEmpty {
                            SectionTitle("Entrou pra revisão", subtitle: "Você vai ver isso de novo pra fixar")
                                .padding(.horizontal, 16)

                            VStack(spacing: 10) {
                                ForEach(wrongItems) { item in
                                    GlassCard {
                                        VStack(alignment: .leading, spacing: 6) {
                                            Text(item.prompt)
                                                .font(.system(size: 14, weight: .bold))

                                            Text("Correto: \(item.correct)")
                                                .font(.system(size: 13, weight: .bold))
                                                .foregroundStyle(AppColors.brandGreen)

                                            Text(item.hint)
                                                .font(.system(size: 12))
                                                .foregroundStyle(.secondary)
                                        }
                                    }
                                    .padding(.horizontal, 16)
                                }
                            }
                        }

                        GlassCard {
                            Button {
                                onCommit()
                                Haptics.success()
                                dismiss()
                            } label: {
                                Text("Concluir")
                                    .font(.system(size: 16, weight: .bold))
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 14)
                                    .background(
                                        LinearGradient(
                                            colors: [AppColors.brandGreen, AppColors.brandBlue],
                                            startPoint: .topLeading,
                                            endPoint: .bottomTrailing
                                        ),
                                        in: RoundedRectangle(cornerRadius: 18)
                                    )
                                    .foregroundStyle(.white)
                            }
                            .buttonStyle(.plain)
                        }
                        .padding(.horizontal, 16)

                        Spacer(minLength: 24)
                    }
                    .padding(.top, 12)
                    .padding(.bottom, 24)
                }
            }
            .navigationTitle("Finalizado")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}
