import SwiftUI

struct ModePill: View {
    let mode: PracticeMode
    let isSelected: Bool

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: mode.icon)
                .font(.system(size: 13, weight: .bold))
            Text(mode.rawValue)
                .font(.system(size: 13, weight: .bold))
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .background {
            RoundedRectangle(cornerRadius: 16)
                .fill(
                    isSelected
                    ? AnyShapeStyle(
                        LinearGradient(
                            colors: mode.gradient,
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    : AnyShapeStyle(Color(.secondarySystemBackground).opacity(0.55))
                )
        }
        .foregroundStyle(isSelected ? .white : .primary)
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(isSelected ? Color.white.opacity(0.18) : Color.primary.opacity(0.08), lineWidth: 1)
        )
        .shadow(color: isSelected ? mode.gradient.first!.opacity(0.28) : .clear, radius: 14, x: 0, y: 10)
        .animation(.spring(response: 0.35, dampingFraction: 0.75), value: isSelected)
    }
}
