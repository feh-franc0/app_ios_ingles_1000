import SwiftUI

struct HomeView: View {
    @EnvironmentObject private var app: AppStore
    @State private var showSession = false
    @State private var selectedMode: PracticeMode = .words

    @State private var pulse = true

    var body: some View {
        ZStack {
            StrongBackground()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 14) {
                    header

                    GlassCard {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("Meta diária")
                                .font(.system(size: 13, weight: .semibold))
                                .foregroundStyle(.secondary)

                            HStack(alignment: .center) {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text("\(app.user.todayXP)/\(app.user.dailyGoalXP) XP hoje")
                                        .font(.system(size: 22, weight: .bold))
                                    Text("Consistência: 5 min por dia > 1h uma vez na semana.")
                                        .font(.system(size: 12))
                                        .foregroundStyle(.secondary)
                                }
                                Spacer()

                                Button {
                                    Haptics.light()
                                    showSession = true
                                } label: {
                                    HStack(spacing: 8) {
                                        Image(systemName: "play.fill")
                                        Text("Continuar")
                                    }
                                    .font(.system(size: 15, weight: .bold))
                                    .padding(.horizontal, 16)
                                    .padding(.vertical, 12)
                                    .background(
                                        LinearGradient(
                                            colors: [AppColors.brandGreen, AppColors.brandBlue],
                                            startPoint: .topLeading,
                                            endPoint: .bottomTrailing
                                        ),
                                        in: RoundedRectangle(cornerRadius: 18)
                                    )
                                    .foregroundStyle(.white)
                                    .shadow(color: AppColors.brandGreen.opacity(0.35), radius: pulse ? 22 : 12, x: 0, y: 10)
                                    .scaleEffect(pulse ? 1.02 : 1.0)
                                    .animation(.easeInOut(duration: 1.2).repeatForever(autoreverses: true), value: pulse)
                                }
                                .buttonStyle(.plain)
                            }

                            ProgressView(value: Double(app.user.todayXP), total: Double(app.user.dailyGoalXP))
                                .tint(AppColors.brandGreen)
                                .scaleEffect(x: 1, y: 1.35, anchor: .center)
                        }
                    }

                    GlassCard {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("Modo de prática")
                                .font(.system(size: 16, weight: .bold))

                            HStack(spacing: 10) {
                                ForEach(PracticeMode.allCases) { mode in
                                    ModePill(mode: mode, isSelected: selectedMode == mode)
                                        .onTapGesture {
                                            Haptics.light()
                                            withAnimation(.spring(response: 0.35, dampingFraction: 0.75)) {
                                                selectedMode = mode
                                            }
                                        }
                                }
                            }
                        }
                    }

                    VStack(spacing: 12) {
                        SectionTitle("Trilha de hoje", subtitle: "10 perguntas • feedback instantâneo • XP e streak")
                        TrailPreview()
                    }

                    Spacer(minLength: 16)
                }
                .padding(.horizontal, 16)
                .padding(.top, 12)
                .padding(.bottom, 24)
            }
        }
        .navigationTitle("Top1000")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                HStack(spacing: 10) {
                    StatChip(icon: "flame.fill", text: "\(app.user.streak)", tint: AppColors.brandOrange)
                    StatChip(icon: "sparkles", text: "\(app.user.xpTotal)", tint: AppColors.brandPurple)
                    StatChip(icon: "circle.hexagongrid.fill", text: "\(app.user.level)", tint: AppColors.brandBlue)
                }
            }
        }
        .sheet(isPresented: $showSession) {
            PracticeSessionView(mode: selectedMode)
                .environmentObject(app)
        }
        .onAppear {
            // Mantém a animação estável (evita “teleporte” de layout)
            pulse = true
        }
    }

    private var header: some View {
        GlassCard {
            HStack(alignment: .center, spacing: 12) {
                ZStack {
                    Circle()
                        .fill(
                            LinearGradient(
                                colors: [AppColors.brandGreen, AppColors.brandBlue],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                        .frame(width: 54, height: 54)
                        .shadow(color: AppColors.brandGreen.opacity(0.28), radius: 14, x: 0, y: 10)

                    Image(systemName: "bolt.fill")
                        .font(.system(size: 20, weight: .bold))
                        .foregroundStyle(.white)
                }

                VStack(alignment: .leading, spacing: 4) {
                    Text("Fala, \(app.user.name) 👋")
                        .font(.system(size: 20, weight: .bold))
                    Text("Vamos praticar as palavras/frases mais usadas e subir de nível.")
                        .font(.system(size: 12))
                        .foregroundStyle(.secondary)
                }

                Spacer()

                ZStack {
                    RoundedRectangle(cornerRadius: 18)
                        .fill(AppColors.card)
                        .frame(width: 72, height: 54)

                    VStack(spacing: 4) {
                        Text("\(app.user.coins)")
                            .font(.system(size: 16, weight: .bold))
                        Text("moedas")
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundStyle(.secondary)
                    }
                }
            }
        }
    }
}

struct TrailPreview: View {
    var body: some View {
        GlassCard {
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    Text("Sessão rápida")
                        .font(.system(size: 16, weight: .bold))
                    Spacer()
                    Text("10 perguntas")
                        .font(.system(size: 12, weight: .bold))
                        .padding(.horizontal, 10)
                        .padding(.vertical, 6)
                        .background(AppColors.brandGreen.opacity(0.14), in: Capsule())
                }

                HStack(spacing: 10) {
                    ForEach(0..<6) { i in
                        Circle()
                            .fill(i < 2 ? AppColors.brandGreen : AppColors.brandBlue.opacity(0.22))
                            .frame(width: 14, height: 14)
                            .overlay(Circle().stroke(Color.white.opacity(0.18), lineWidth: 1))
                    }
                    Spacer()
                    Image(systemName: "arrow.right")
                        .font(.system(size: 16, weight: .bold))
                        .foregroundStyle(.secondary)
                }

                Text("Dica: errou → vai pra revisão automaticamente.")
                    .font(.system(size: 12))
                    .foregroundStyle(.secondary)
            }
        }
    }
}
