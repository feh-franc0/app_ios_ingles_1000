import SwiftUI

enum AppColors {
    static let brandGreen = Color(red: 0.12, green: 0.82, blue: 0.36)
    static let brandBlue  = Color(red: 0.12, green: 0.58, blue: 1.00)
    static let brandPurple = Color(red: 0.66, green: 0.32, blue: 0.96)
    static let brandOrange = Color(red: 1.00, green: 0.56, blue: 0.18)
    static let brandRed = Color(red: 0.98, green: 0.25, blue: 0.30)

    static let card = Color(.secondarySystemBackground).opacity(0.9)
    static let stroke = Color.white.opacity(0.10)
}
