import SwiftUI

struct StrongBackground: View {
    @State private var animate = false

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    AppColors.brandGreen.opacity(0.18),
                    AppColors.brandBlue.opacity(0.12),
                    Color(.systemBackground)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            RadialGradient(
                colors: [AppColors.brandPurple.opacity(animate ? 0.22 : 0.10), .clear],
                center: .topTrailing,
                startRadius: 20,
                endRadius: 520
            )
            .ignoresSafeArea()
            .animation(.easeInOut(duration: 2.2).repeatForever(autoreverses: true), value: animate)

            RadialGradient(
                colors: [AppColors.brandOrange.opacity(animate ? 0.14 : 0.06), .clear],
                center: .bottomLeading,
                startRadius: 20,
                endRadius: 520
            )
            .ignoresSafeArea()
            .animation(.easeInOut(duration: 2.6).repeatForever(autoreverses: true), value: animate)
        }
        .onAppear { animate = true }
    }
}
