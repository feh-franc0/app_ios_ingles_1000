import Combine
import Foundation

final class AppStore: ObservableObject {
    @Published var user = UserState()
    @Published var content = ContentRepository()
    @Published var reviewPool: [ReviewItem] = []

    func addReview(_ item: ReviewItem) {
        if !reviewPool.contains(where: { $0.key == item.key }) {
            reviewPool.insert(item, at: 0)
        }
        if reviewPool.count > 50 { reviewPool = Array(reviewPool.prefix(50)) }
    }

    func completeSession(xpGained: Int, correctRate: Double) {
        user.xpTotal += xpGained
        user.todayXP = min(user.dailyGoalXP, user.todayXP + xpGained)

        let newLevel = max(1, user.xpTotal / 250 + 1)
        if newLevel != user.level {
            user.level = newLevel
            Haptics.success()
        }
    }
}
