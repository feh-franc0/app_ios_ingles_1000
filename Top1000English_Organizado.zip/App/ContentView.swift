import SwiftUI

// MARK: - App Entry View (Tabs)

struct ContentView: View {
    @StateObject private var app = AppStore()

    var body: some View {
        NavigationStack {
            TabView {
                HomeView()
                    .environmentObject(app)
                    .tabItem { Label("Início", systemImage: "house.fill") }

                PathView()
                    .environmentObject(app)
                    .tabItem { Label("Trilha", systemImage: "map.fill") }

                ReviewView()
                    .environmentObject(app)
                    .tabItem { Label("Revisão", systemImage: "arrow.triangle.2.circlepath") }

                ProfileView()
                    .environmentObject(app)
                    .tabItem { Label("Perfil", systemImage: "person.fill") }
            }
            .tint(AppColors.brandGreen)
        }
    }
}

#Preview {
    ContentView()
}
